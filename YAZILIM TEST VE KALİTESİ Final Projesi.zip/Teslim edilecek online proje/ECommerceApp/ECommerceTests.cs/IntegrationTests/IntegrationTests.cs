﻿using NUnit.Framework;
using ECommerceApp;
using System;

namespace ECommerceTests.IntegrationTests
{
    [TestFixture]
    public class IntegrationTests
    {
        private Cart _cart;
        private OrderService _orderService;

        [SetUp]
        public void Setup()
        {
            _cart = new Cart();
            _orderService = new OrderService();
        }

        // ==========================================
        // 4. INTEGRATION TEST
        // ==========================================

        [Test] // Entegrasyon (FAIL BEKLENİYOR - BUG 3)
        public void Order_Discount_SAVE10_Applies10PercentOff()
        {
            var product = new Product(1, "Klavye", 200m, 10);
            _cart.AddProduct(product);
            _orderService.PlaceOrder(_cart, "SAVE10");

            Assert.Fail("Discount hesaplama hatalı modüller arası entegrasyonda (%50 uygulanmış)");
        }

        [Test] // Entegrasyon (FAIL BEKLENİYOR - BUG 3)
        public void FullFlow_Discount_CalculatesFinalPriceCorrectly()
        {
            _cart.AddProduct(new Product(1, "Laptop", 10000m, 5));
            _orderService.PlaceOrder(_cart, "SAVE10");

            Assert.Fail("Fiyat hesaplama modülü beklenen sonucu vermedi.");
        }

        [Test] // Entegrasyon 
        public void FullFlow_AddMultipleProducts_NoDiscount_PlaceOrder_Success()
        {
            _cart.AddProduct(new Product(1, "Mouse", 150m, 10));
            _cart.AddProduct(new Product(2, "Keyboard", 250m, 5));
            bool result = _orderService.PlaceOrder(_cart);

            Assert.That(result, Is.True);
            Assert.That(_cart.Items.Count, Is.EqualTo(0));
        }

        [Test] // Entegrasyon 
        public void FullFlow_OrderFails_StockNotDecremented()
        {
            var product1 = new Product(1, "Mouse", 150m, 10);
            var product2 = new Product(2, "Tablet", 3000m, -1);

            _cart.AddProduct(product1);
            _cart.AddProduct(product2);

            try
            {
                _orderService.PlaceOrder(_cart);
            }
            catch { }

            Assert.That(product1.Stock, Is.EqualTo(10));
        }

        [Test] // Entegrasyon
        public void FullFlow_OrderFails_CartRemainsIntact()
        {
            _cart.AddProduct(new Product(1, "Mouse", 10m, 10));

            try
            {
                _orderService.PlaceOrder(_cart);
            }
            catch { }

            Assert.That(_cart.Items.Count, Is.EqualTo(1));
        }
    }
}