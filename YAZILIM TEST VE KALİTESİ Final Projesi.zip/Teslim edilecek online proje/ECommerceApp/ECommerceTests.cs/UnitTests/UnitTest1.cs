using NUnit.Framework;
using ECommerceApp;
using System;

namespace ECommerceTests.UnitTests
{
    [TestFixture]
    public class UnitTests
    {
        private Cart _cart;
        private OrderService _orderService;

        [SetUp]
        public void Setup()
        {
            _cart = new Cart();
            _orderService = new OrderService();
        }

        // ==========================================
        // 1. UNIT TEST (WHITE BOX) - 8 Test Case
        // ==========================================
        [Test]
        public void Cart_AddProduct_IncreasesItemCount()
        {
            _cart.AddProduct(new Product(1, "Mouse", 150m, 10));
            Assert.That(_cart.Items.Count, Is.EqualTo(1));
        }

        [Test]
        public void Cart_GetTotal_ReturnsCorrectSum()
        {
            _cart.AddProduct(new Product(1, "Mouse", 150m, 10));
            _cart.AddProduct(new Product(2, "Keyboard", 250m, 5));
            Assert.That(_cart.GetTotal(), Is.EqualTo(400m));
        }

        [Test]
        public void Cart_Clear_EmptiesCart()
        {
            _cart.AddProduct(new Product(1, "Mouse", 150m, 10));
            _cart.Clear();
            Assert.That(_cart.Items.Count, Is.EqualTo(0));
        }

        [Test]
        public void Cart_Clear_OnEmptyCart_DoesNotThrow()
        {
            Assert.DoesNotThrow(() => _cart.Clear());
            Assert.That(_cart.Items.Count, Is.EqualTo(0));
        }

        [Test]
        public void Product_Initialization_SetsPropertiesCorrectly()
        {
            var product = new Product(1, "Monitor", 3000m, 5);
            Assert.That(product.Name, Is.EqualTo("Monitor"));
            Assert.That(product.Stock, Is.EqualTo(5));
        }

        [Test]
        public void Product_Price_CanBeUpdatedDirectly()
        {
            var product = new Product(1, "Kablo", 50m, 20);
            product.Price = 75m;
            Assert.That(product.Price, Is.EqualTo(75m));
        }

        [Test]
        public void Cart_RemoveProduct_DecreasesItemCount()
        {
            var product = new Product(1, "Mouse", 150m, 10);
            _cart.AddProduct(product);
            _cart.RemoveProduct(product);
            Assert.That(_cart.Items.Count, Is.EqualTo(0));
        }

        [Test]
        public void Cart_RemoveNonExistentProduct_DoesNothing()
        {
            var product1 = new Product(1, "Mouse", 150m, 10);
            var product2 = new Product(2, "Klavye", 300m, 5);
            _cart.AddProduct(product1);
            _cart.RemoveProduct(product2);
            Assert.That(_cart.Items.Count, Is.EqualTo(1));
        }

        // ==========================================
        // 2. BLACK BOX TEST (EP & BVA) - 9 Test Case
        // ==========================================

        [Test]
        public void Order_Amount_99_ThrowsMinOrderException()
        {
            _cart.AddProduct(new Product(1, "Kablo", 99m, 10));
            Assert.Throws<InvalidOperationException>(() => _orderService.PlaceOrder(_cart));
        }

        [Test]
        public void Order_Amount_0_ThrowsMinOrderException()
        {
            Assert.Throws<InvalidOperationException>(() => _orderService.PlaceOrder(_cart));
        }

        [Test]
        public void Order_Amount_100_Succeeds()
        {
            _cart.AddProduct(new Product(1, "Kulakl�k", 100m, 10));
            Assert.That(_orderService.PlaceOrder(_cart), Is.True);
        }

        [Test]
        public void Order_Amount_101_Succeeds()
        {
            _cart.AddProduct(new Product(1, "Kulakl�k", 101m, 10));
            Assert.That(_orderService.PlaceOrder(_cart), Is.True);
        }

        [Test]
        public void Order_With_Valid_Total_Succeeds()
        {
            _cart.AddProduct(new Product(1, "Laptop", 15000m, 5));
            Assert.That(_orderService.PlaceOrder(_cart), Is.True);
        }

        [Test]
        public void Order_With_Valid_Stock_Succeeds()
        {
            _cart.AddProduct(new Product(1, "Mouse", 200m, 5));
            Assert.DoesNotThrow(() => _orderService.PlaceOrder(_cart));
        }

        [Test]
        public void Order_With_Exactly_5_Items_Succeeds()
        {
            _cart.AddProduct(new Product(1, "�r�n1", 100m, 10));
            _cart.AddProduct(new Product(2, "�r�n2", 100m, 10));
            _cart.AddProduct(new Product(3, "�r�n3", 100m, 10));
            _cart.AddProduct(new Product(4, "�r�n4", 100m, 10));
            _cart.AddProduct(new Product(5, "�r�n5", 100m, 10));

            Assert.DoesNotThrow(() => _orderService.PlaceOrder(_cart), "Maksimum 5 �r�n eklenebilmeli.");
        }

        [Test]
        public void Order_MaxLimit_BoundaryTest_5_Items()
        {
            for (int i = 1; i <= 5; i++)
            {
                _cart.AddProduct(new Product(i, "Test", 150m, 5));
            }
            Assert.That(_orderService.PlaceOrder(_cart), Is.True);
        }

        [Test]
        public void Order_With_4_Items_Succeeds()
        {
            for (int i = 1; i <= 4; i++)
            {
                _cart.AddProduct(new Product(i, "Test", 150m, 5));
            }
            Assert.That(_orderService.PlaceOrder(_cart), Is.True);
        }

        // ==========================================
        // 3. GRAY BOX TEST - 6 Test Case
        // ==========================================

        [Test]
        public void Order_Stock_0_ThrowsOut_Of_Stock_Exception()
        {
            _cart.AddProduct(new Product(1, "Tablet", 3000m, 0));
            Assert.Throws<InvalidOperationException>(() => _orderService.PlaceOrder(_cart));
        }

        [Test]
        public void Order_Boundary_Stock_Zero_Test()
        {
            var p = new Product(1, "K�l�f", 150m, 0);
            _cart.AddProduct(p);
            var ex = Assert.Throws<InvalidOperationException>(() => _orderService.PlaceOrder(_cart));
            Assert.That(ex.Message, Does.Contain("Out of stock"));
        }

        [Test]
        public void OrderService_State_AfterOrder_CartIsCleared()
        {
            _cart.AddProduct(new Product(1, "Mouse", 150m, 10));
            _orderService.PlaceOrder(_cart);
            Assert.That(_cart.Items.Count, Is.EqualTo(0));
        }

        [Test]
        public void OrderService_State_AfterOrder_StockIsDecremented()
        {
            var product = new Product(1, "Mouse", 150m, 10);
            _cart.AddProduct(product);
            _orderService.PlaceOrder(_cart);
            Assert.That(product.Stock, Is.EqualTo(9));
        }

        [Test] // EP
        public void Order_Discount_InvalidCode_AppliesNoDiscount()
        {
            var product = new Product(1, "Mouse", 200m, 10);
            _cart.AddProduct(product);
            _orderService.PlaceOrder(_cart, "WRONGCODE");
            Assert.That(product.Stock, Is.EqualTo(9));
        }

        [Test]
        public void Order_Discount_EmptyCode_IgnoresDiscount()
        {
            var product = new Product(1, "Mouse", 200m, 10);
            _cart.AddProduct(product);
            _orderService.PlaceOrder(_cart, "");
            Assert.That(product.Stock, Is.EqualTo(9));
        }
    }
}