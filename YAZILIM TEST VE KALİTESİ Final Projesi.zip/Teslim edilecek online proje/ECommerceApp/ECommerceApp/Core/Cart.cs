﻿using System.Collections.Generic;
using System.Linq;

namespace ECommerceApp
{
    public class Cart
    {
        public List<Product> Items { get; private set; } = new List<Product>();

        public void AddProduct(Product product)
        {
            Items.Add(product);
        }

        public void RemoveProduct(Product product)
        {
            Items.Remove(product);
        }

        public decimal GetTotal()
        {
            return Items.Sum(x => x.Price);
        }

        public void Clear()
        {
            Items.Clear();
        }
    }
}