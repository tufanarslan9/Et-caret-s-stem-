﻿using System;

namespace ECommerceApp
{
    public class OrderService
    {
        private const decimal MinOrderAmount = 100.0m;

        public bool PlaceOrder(Cart cart, string discountCode = "")
        {
            decimal total = cart.GetTotal();

            // BUG 1: Minimum sipariş tutarı kontrolü hatalı. 100 olması gerekirken < 50 yazılmış.
            if (total < 50.0m)
            {
                throw new InvalidOperationException($"Minimum order amount is {MinOrderAmount} TL.");
            }

            // BUG 2: Stok kontrolü yanlış. Eşittir (=) unutulmuş, 0 stokta da siparişe izin veriyor.
            foreach (var item in cart.Items)
            {
                if (item.Stock < 0)
                {
                    throw new InvalidOperationException($"Out of stock: {item.Name}");
                }
            }

            // BUG 4: YENİ EKLENEN HATA
            // Sepette maksimum 5 farklı ürüne izin verilmelidir (> 5 olmalı).
            // Ancak yanlışlıkla >= 5 yazıldığı için tam 5 üründe sistem hata veriyor.
            if (cart.Items.Count >= 5)
            {
                throw new InvalidOperationException("Maximum 5 different products allowed per order.");
            }

            decimal discountAmount = 0;
            if (discountCode == "SAVE10")
            {
                // BUG 3: İndirim uygulaması hatalı. %10 yerine %50 indirim uygulanıyor.
                discountAmount = total * 0.50m;
            }

            decimal finalTotal = total - discountAmount;

            // Sipariş sonrası stok düşme
            foreach (var item in cart.Items)
            {
                item.Stock -= 1;
            }

            cart.Clear();
            return true;
        }
    }
}